
<!--
<template>
  <div>
    <v-header></v-header>
    <main ref="container"
          class="content-container">
      <nuxt />
    </main>
    <v-footer></v-footer>
  </div>
</template> 
-->

<template>
  <main ref="container"
        class="content-container ly_h100">
    <nuxt />
  </main>
</template>
<script>

export default {

}
</script>

<style lang="stylus" scoped></style>
